import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;


public class ReadFile {
	BufferedWriter out;
	Scanner in = new Scanner(System.in);

	int noOfStudents;
	String registrationNumber;
	String fullName;
	String fatherName;
	String motherName;
	String dateOfBirth;
	String nidNumber;
	String address;
	String enterToSearch;


public ReadFile() {}

	public void Readfile(){

		try {
			out = new BufferedWriter(new FileWriter("final6.txt",true));
			System.out.println("enter the number of student's record you want to add");
			noOfStudents = in.nextInt();
			for(int i=1;i<=noOfStudents;++i) {
				System.out.println("enter record for Student"+i);
				System.out.println("enter your Registration Number");
				in.nextLine();
				registrationNumber = in.nextLine();
				out.write(registrationNumber+",");

				System.out.println("enter your full name");
				fullName = in.nextLine();
				out.write(fullName+",");

				System.out.println("enter  father's name");
				fatherName = in.nextLine();
				out.write(fatherName+",");



				System.out.println("enter  mother's name");
				motherName = in.nextLine();
				out.write(motherName+",");

				System.out.println("enter your date of birthday(dd-mm-yy)");
				dateOfBirth = in.nextLine();
				out.write(dateOfBirth+",");

				System.out.println("enter your nid numver");
				nidNumber = in.nextLine();
				out.write(nidNumber+",");


				System.out.println("enter your address");
				address = in.nextLine();
				out.write(address+",");	
				out.newLine();
			}
			// File fomr = new File("C:\\Users\\sudip\\eclipse-workspace\\Assign\\personalInfo2.txt");
			//String fom = FileUtils.readFileToString(fomr);
			out.close();
		}catch(IOException e){
			System.out.println("There was a problem:" + e);
		}
	}

	public void searchForPersonal() throws IOException{
		System.out.println("---------------");
		Scanner in = new Scanner(System.in);
		InputStream is = new FileInputStream("final6.txt");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is));

		String read=" ";
		System.out.println("enter registration number to search");
		String enterToSearch = in.nextLine();
		int flag=0;
		while ((read = buf.readLine()) != null) {
			int i=0;
			String split3[] = read.split(",");
			if(split3[0].equals(enterToSearch)){
				flag=1;
				System.out.println("Your Personal Information : ");
				System.out.println("Registration No: "+split3[0]+"\nFull name:"+split3[1]+"\nfather's name:"+split3[2]+"\nmother's name:"+split3[3]+"\ndate of birth:"+split3[4]+"\nNID number:"+split3[5]+"\naddress:"+split3[6]);
			}
i++;
		}
		if(flag==0){
			System.out.println("Invalid Registration Number.....");
		}






		//		String fileAsString = sb.toString();
		//		System.out.println(fileAsString);
		//		System.out.println("enter registration numver to search");
		//		String enterToSearch = in.nextLine();
		//		boolean bool = fileAsString.contains(enterToSearch);
		//		System.out.println("Data found");
		//		



	}
}


