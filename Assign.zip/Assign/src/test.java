import java.io.IOException;

public class test {

	public static void main(String[]args) throws IOException {
		ReadFile personalInfo = new ReadFile();
		//personalInfo.Readfile();
		//personalInfo.searchForPersonal();
		WriteFile academicInfo = new WriteFile();
		//academicInfo.Writefile();
		academicInfo.searchForAca();
	}
}
