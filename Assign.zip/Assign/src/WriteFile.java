import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;


public class WriteFile {
	BufferedWriter out;
	Scanner in = new Scanner(System.in);

	int noOfStudents;
	String registrationNumber;
	String Session;
	String rollNumber;
	String emailId;
	String studyingYear;
	String Semester;
	String enterToSearch;


	public WriteFile() {}

	public void Writefile(){

		try {
			out = new BufferedWriter(new FileWriter("Filet2.txt",true));
			System.out.println("enter the number of student's record you want to add");
			noOfStudents = in.nextInt();
			for(int i=1;i<=noOfStudents;++i) {
				System.out.println("enter academic record for Student"+i);
				System.out.println("enter your Registration Number");
				in.nextLine();
				registrationNumber = in.nextLine();
				out.write(registrationNumber+",");

				System.out.println("enter your Session");
				Session = in.nextLine();
				out.write(Session+",");

				System.out.println("enter  your class roll number");
				rollNumber = in.nextLine();
				out.write(rollNumber+",");

				System.out.println("enter  your email id");
				emailId = in.nextLine();
				out.write(emailId+",");

				System.out.println("enter your studyingYear");
				studyingYear = in.nextLine();
				out.write(studyingYear+",");

				System.out.println("enter your StudyingSemester");
				Semester = in.nextLine();
				out.write(Semester+",");
			}
			out.close();
		}catch(IOException e){
			System.out.println("There was a problem:" + e);
		}
	}
	public void searchForAca() throws IOException{
		System.out.println("---------------");
		Scanner in = new Scanner(System.in);
		InputStream is = new FileInputStream("Filet2.txt");
		BufferedReader buf = new BufferedReader(new InputStreamReader(is));

		String read=" ";
		System.out.println("enter registration number to search");
		String enterToSearch = in.nextLine();
		int flag=0;
		
			while ((read = buf.readLine()) != null) {
				int i=0;
				String split[] = read.split(",");
				if(split[0].equals(enterToSearch)){
					flag=1;
					System.out.println("Your Academic Information : ");
					System.out.println("Registration No: "+split[0]+"\nSession:"+split[1]+"\nRoll Number:"+split[2]+"\nemail ID:"+split[3]+"\nstudying year:"+split[4]+"\nstudying semester:"+split[5]);
				i++;
				}
			}
		
		if(flag==0){
			System.out.println("Invalid Registration Number.....");
		}
	}
}


