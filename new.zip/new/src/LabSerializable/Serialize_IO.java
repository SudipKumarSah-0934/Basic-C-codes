/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LabSerializable;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author iit
 */
public class Serialize_IO {
	private static String filename = "serialize_data.txt";
	public void writeSerializeListObject(){
		bankAccount s1 = new bankAccount("Fahim Ahmed", "Agrani", 1251630, "+8801775627730", "Male", "Tk.5000");
		bankAccount s2 = new bankAccount("Mehedi Hasan", "Agrani", 1251635, "+8801776490038", "Male", "Tk.10000");
		bankAccount s3 = new bankAccount("Muntakim Hye Rashik", "Agrani", 1251625, "+8801775455567", "Male", "Tk.2000");

		ArrayList<bankAccount> accountHoldersList = new ArrayList<>();

		accountHoldersList.add(s1);
		accountHoldersList.add(s2);
		accountHoldersList.add(s3);

		FileOutputStream fout = null;
		ObjectOutputStream object_out_for_serializable = null;
		try {
			fout = new FileOutputStream(filename);
			object_out_for_serializable = new ObjectOutputStream(fout);

			object_out_for_serializable.writeObject(accountHoldersList);
			object_out_for_serializable.flush();

			System.out.println("Success to write serializable!!");

		} catch (FileNotFoundException ex) {
			System.out.println("FileOutputStream in " + ex.toString());
		} catch (IOException ex) {
			System.out.println("ObjectOutputStream in " + ex.toString());
		} 

	}

	public void readDeserializeListObject(){

		try {
			ObjectInputStream object_in_for_deserializable =
					new ObjectInputStream(new FileInputStream(filename));

			ArrayList<bankAccount> listOfAccountHolders = 
					(ArrayList<bankAccount>) object_in_for_deserializable.readObject();

			for (bankAccount deserializeaccountholders : listOfAccountHolders){
				System.out.println("Account Name: " + deserializeaccountholders.accName+"," + 
						"Account Number: " + deserializeaccountholders.accNumber+","+ 
						"Mobile Number: " + deserializeaccountholders.mobileNumber+","+ 
						"Gender: " + deserializeaccountholders.Gender+","+ 
						"Amount: " + deserializeaccountholders.Amount);
			}

		} catch (IOException ex) {
			Logger.getLogger(Serialize_IO.class.getName()).log(Level.SEVERE, null, ex);
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Serialize_IO.class.getName()).log(Level.SEVERE, null, ex);
		}

	}


}
