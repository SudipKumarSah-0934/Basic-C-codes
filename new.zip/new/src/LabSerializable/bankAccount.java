/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LabSerializable;

import java.io.Serializable;

/**
 *
 * @author iit
 */
public class bankAccount implements Serializable{

    String accName;
    transient String bankName;
    int accNumber;
    String mobileNumber;
    String Gender;
    String Amount;
    
    protected static int accountholders = 0;
    
    public bankAccount() {
        
        this("Unknown", "Unknown", 0, "Unknown", "Unknown", "Unknown");    
    }

    public bankAccount(String accName, String bankName, int  accNumber, String mobileNumber, String Gender, String Amount) {
        this.accName = accName;
        this.bankName = bankName;
        this.accNumber = accNumber;
        this.mobileNumber = mobileNumber;
        this.Gender = Gender;
        this.Amount = Amount;
        
        if (bankName.equalsIgnoreCase("Agrani"))
                accountholders++;
        
    }
    
    public void printName(){
        System.out.println("Hello " + this.accName);
    }
    
    public static int getNumberOfAccountHolders(){
        return accountholders;
    }
    
    
}
