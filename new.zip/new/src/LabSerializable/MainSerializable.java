package LabSerializable;

/**
 *
 * @author iit
 */
public class MainSerializable {

    public static void main(String[] args) {
        Serialize_IO serial_io = new Serialize_IO();
        serial_io.writeSerializeListObject();
        serial_io.readDeserializeListObject();
    }
    
    
    
}
